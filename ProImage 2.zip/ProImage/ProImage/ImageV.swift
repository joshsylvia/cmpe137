//
//  ImageV.swift
//  ProImage
//
//  Created by MacBook Owner on 9/28/16.
//  Copyright © 2016 MacBook Owner. All rights reserved.
//

import UIKit

class ImageV: UIImageView {
    

    
}